import { defaultTimeFilter, resolveTimeRange, parseProtectedSites, isProtectedUrl } from './history-filters.mjs';
import { createLauncher } from './launcher.mjs';
import { createActivityLog } from './activity-log.mjs';
import { createNameplateStore } from './nameplate-store.mjs';
import { createUpdateChecker, isNewerVersion } from './update-check.mjs';
import { createAutoCleanup, AUTO_CLEANUP_ALARM } from './auto-cleanup.mjs';
import { WORKSPACE_TOOLS_KEY, MANUAL_CLEANUP_KEY, readWorkspaceTools, readProtectedUrls, validateSavedSearch, validateProtectedUrls, validateLinkRule, validateWebsiteLabel, websiteHostname, cleanLink } from './workspace-tools.mjs';
import { validateLocalBackup, pausedTaskConfig } from './local-backup.mjs';
import { readBrowsingPreferences } from './browsing-preferences.mjs';
import { validateConfig as validateSyncConfig, validateConnection, CONNECTION_KEY } from './config-sync.mjs';
import { normalizeRule } from './auto-cleanup-model.mjs';
import { createAutomaticLinkCleanup } from './automatic-link-cleanup.mjs';
import { installAgentBridge, isAgentMessage } from './agent-bridge.mjs';
import { agentError } from './agent-access.mjs';

const launcher = createLauncher(chrome);
void launcher.register().catch(() => {});

const handoffs = new Map();
const jobs = new Map();
const activityLog = createActivityLog(chrome.storage.local);
const nameplates = createNameplateStore(chrome.storage.local);
const checkForUpdate = createUpdateChecker(chrome);
const modes = new Set(['smart', 'host-subdomains', 'host-exact', 'contains']);
let policyQueue = Promise.resolve();
let applyingUpdate = false;
let cleanupQueue = Promise.resolve();
let queuedCleanups = 0;
let agentBridge;

function withPolicyLock(operation) {
  const result = policyQueue.then(operation);
  policyQueue = result.catch(() => {});
  return result;
}

const deletionRunning = () => queuedCleanups > 0 || autoCleanup.busy() || [...jobs.values()].some(job => ['deleting', 'verifying'].includes(job.phase));
function queueCleanup(operation) {
  queuedCleanups++;
  const task = cleanupQueue.then(operation);
  cleanupQueue = task.catch(() => {});
  return task.finally(() => {
    queuedCleanups--;
    void withPolicyLock(publishUpdateState).catch(() => {});
  });
}
const autoCleanup = createAutoCleanup(chrome, {
  readProtectedSites,
  readProtectedUrls: () => readProtectedUrls(chrome.storage.local),
  recordActivity: (pages, items, canRecord) => activityLog.record(pages, items, 'automatic', canRecord),
  runExclusive: queueCleanup,
  isBusy: () => applyingUpdate || queuedCleanups > 0,
  onStateChange: () => {
    void withPolicyLock(publishUpdateState).catch(() => {});
    void agentBridge?.reconcile().catch(() => {});
  },
});
const automaticLinks = createAutomaticLinkCleanup(chrome);
// Chrome only exposes connectNative after the user grants nativeMessaging.
// The Agent panel still needs state and settings before the first grant.
if (chrome.permissions) agentBridge = installAgentBridge(chrome, autoCleanup);

async function readUpdateState() {
  const installedVersion = chrome.runtime.getManifest().version;
  const { extensionUpdateCheck } = await chrome.storage.local.get('extensionUpdateCheck');
  const check = extensionUpdateCheck?.installedVersion === installedVersion ? extensionUpdateCheck : null;
  const { extensionUpdate } = await chrome.storage.session.get('extensionUpdate');
  // Session metadata survives worker suspension, but must not advertise an already installed version.
  if (!extensionUpdate || extensionUpdate.installedVersion !== chrome.runtime.getManifest().version ||
      !isNewerVersion(extensionUpdate.version, extensionUpdate.installedVersion)) return { update: null, check };
  return { update: { version: extensionUpdate.version, busy: deletionRunning() }, check };
}

async function publishUpdateState() {
  const { update } = await readUpdateState();
  if (update) await chrome.storage.session.set({ extensionUpdate: { ...update, installedVersion: chrome.runtime.getManifest().version } });
}

function recordAvailableUpdate(version) {
  if (!isNewerVersion(version, chrome.runtime.getManifest().version)) return Promise.resolve();
  return withPolicyLock(() => chrome.storage.session.set({ extensionUpdate: {
    version, installedVersion: chrome.runtime.getManifest().version, busy: deletionRunning(),
  } }));
}

chrome.runtime.onUpdateAvailable.addListener(({ version }) => {
  void recordAvailableUpdate(version).catch(() => {});
});

async function readProtectedSites() {
  const data = await chrome.storage.local.get('protectedSites');
  if (data.protectedSites === undefined) return [];
  if (!Array.isArray(data.protectedSites) || !data.protectedSites.every(site => typeof site === 'string')) throw new Error('RULES_UNAVAILABLE');
  return parseProtectedSites(data.protectedSites.join('\n'));
}

async function openWorkspace(query, mode, filters) {
  resolveTimeRange(filters);
  const handoffId = crypto.randomUUID();
  // Only a one-use ID enters the tab URL; domains and filters stay in memory.
  handoffs.set(handoffId, { query, mode, filters, expires: Date.now() + 60000 });
  try { await chrome.tabs.create({ url: chrome.runtime.getURL(`manager.html#handoff=${handoffId}`) }); }
  catch (error) { handoffs.delete(handoffId); throw error; }
  setTimeout(() => handoffs.delete(handoffId), 60000);
}

function websiteHost(value) {
  try {
    const url = new URL(value);
    if (['http:', 'https:'].includes(url.protocol) && url.hostname) return url.hostname;
  } catch {}
  throw new Error('CURRENT_SITE_UNAVAILABLE');
}

chrome.runtime.onInstalled.addListener(details => {
  if (details?.reason === 'install') void nameplates.prepareReveal().catch(() => {});
  chrome.contextMenus.create({ id: 'sweep-site', title: chrome.i18n.getMessage('sweepSite'), contexts: ['page'], documentUrlPatterns: ['http://*/*', 'https://*/*'] });
  if (details?.reason === 'install') void withPolicyLock(async () => {
    const { activityScrollHint } = await chrome.storage.local.get('activityScrollHint');
    if (activityScrollHint === undefined) await chrome.storage.local.set({ activityScrollHint: { installedAt: Date.now(), lastShownOn: null } });
  }).catch(() => {});
});
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId !== 'sweep-site') return;
  try { void openWorkspace(websiteHost(info.pageUrl), 'host-exact', defaultTimeFilter()).catch(() => {}); } catch {}
});

function trustedPage(sender) {
  if (sender.id !== chrome.runtime.id || (sender.frameId != null && sender.frameId !== 0)) return false;
  const url = new URL(sender.url);
  return ['popup.html', 'manager.html', 'auto-cleanup.html', 'sync.html'].some(page => `${url.protocol}//${url.host}${url.pathname}` === chrome.runtime.getURL(page));
}

function snapshot(job) {
  return { id: job.id, total: job.total, completed: job.completed, phase: job.phase, remaining: job.remaining, privateCleanup: job.privateCleanup };
}

function ownerKey(message, sender) {
  if (sender.documentId) return `document:${sender.documentId}`;
  // Chrome omits documentId/frameId/tab for real toolbar popups, unlike extension tabs.
  if (new URL(sender.url).pathname !== '/popup.html' || sender.tab != null || sender.frameId != null ||
      typeof message.clientId !== 'string' || !/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(message.clientId)) {
    throw new Error('Invalid popup identity');
  }
  return `popup:${message.clientId}`;
}

async function runDeletion(job, urls, details) {
  let cursor = 0;
  try {
    await Promise.all(Array.from({ length: Math.min(8, urls.length) }, async () => {
      while (cursor < urls.length) {
        const url = urls[cursor++];
        for (let attempt = 0; attempt < 3; attempt++) {
          try { await chrome.history.deleteUrl({ url }); break; } catch {}
        }
        job.completed++;
      }
    }));
    job.phase = 'verifying';
    cursor = 0;
    const remaining = [];
    await Promise.all(Array.from({ length: Math.min(8, urls.length) }, async () => {
      while (cursor < urls.length) {
        const url = urls[cursor++];
        if ((await chrome.history.getVisits({ url })).length) remaining.push(url);
      }
    }));
    job.remaining = remaining;
    // Record the worker's verified result once, even if its initiating view has closed.
    // A local statistics failure must not turn a completed deletion into a failed deletion.
    const retained = new Set(remaining);
    if (!job.privateCleanup) await activityLog.record(urls.length - remaining.length, urls.filter(url => !retained.has(url)).map(url => ({ url, ...details.get(url) }))).catch(() => {});
    job.phase = remaining.length ? 'partial' : 'done';
  } catch { job.phase = 'verifyFailed'; }
  finally {
    // Only a minimal marker survives interruption. Never persist a pending URL queue.
    const latest = (await chrome.storage.local.get(MANUAL_CLEANUP_KEY).catch(() => ({})))[MANUAL_CLEANUP_KEY];
    if (latest?.id === job.id && job.phase !== 'verifyFailed') await chrome.storage.local.remove(MANUAL_CLEANUP_KEY).catch(() => {});
    void withPolicyLock(publishUpdateState).catch(() => {});
    // Briefly retain results for the initiating page, without persisting history.
    setTimeout(() => jobs.delete(job.id), 60000);
  }
}

async function handleMessage(message, sender, owner, modal = false) {
  if (new URL(sender.url).pathname === '/sync.html' && !['get-local-backup', 'restore-local-backup'].includes(message.type)) throw new Error('Invalid page');
  if (isAgentMessage(message)) return agentBridge?.handle(message);
  if (message.type === 'get-link-cleanup-state') return automaticLinks.reconcile();
  if (message.type === 'set-link-cleanup-automatic') return withPolicyLock(() => automaticLinks.setAutomatic(message.hostname, message.enabled));
  if (message.type === 'pause-link-cleanup') return withPolicyLock(() => automaticLinks.pause(message.paused));
  if (message.type === 'open-cleaned-link') {
    const result = cleanLink(message.url, message.rule);
    if (!result.removed.length) throw new Error('LINK_UNAVAILABLE');
    // A foreground tab closes Chrome's toolbar popup and loses its in-memory selection.
    const background = new URL(sender.url).pathname === '/popup.html';
    await chrome.tabs.create({ url: result.url, active: !background });
    return { background };
  }
  if (message.type === 'get-workspace-tools') {
    const tools = await readWorkspaceTools(chrome.storage.local);
    const marker = (await chrome.storage.local.get(MANUAL_CLEANUP_KEY))[MANUAL_CLEANUP_KEY];
    const active = marker?.id && jobs.get(marker.id);
    return { tools, interrupted: marker?.pending === true && (!active || active.phase === 'verifyFailed') };
  }
  if (message.type === 'dismiss-cleanup-notice') return withPolicyLock(async () => {
    if (deletionRunning()) throw new Error('RULES_BUSY');
    await chrome.storage.local.remove(MANUAL_CLEANUP_KEY); return {};
  });
  if (message.type === 'clear-local-activity') return withPolicyLock(async () => {
    if (deletionRunning()) throw new Error('RULES_BUSY');
    return queueCleanup(() => activityLog.clear());
  });
  if (['save-workspace-search', 'remove-workspace-search', 'save-url-protection', 'save-link-rule', 'remove-link-rule', 'save-website-label'].includes(message.type)) return withPolicyLock(async () => {
    if (applyingUpdate || (message.type === 'save-url-protection' && deletionRunning())) throw new Error('RULES_BUSY');
    const tools = await readWorkspaceTools(chrome.storage.local);
    if (message.type === 'save-workspace-search') {
      const saved = validateSavedSearch(message.search);
      tools.searches = tools.searches.some(item => item.id === saved.id) ? tools.searches.map(item => item.id === saved.id ? saved : item) : [...tools.searches, saved];
    } else if (message.type === 'remove-workspace-search') tools.searches = tools.searches.filter(item => item.id !== message.id);
    else if (message.type === 'save-url-protection') {
      const [url] = validateProtectedUrls([message.url]);
      if (typeof message.protected !== 'boolean') throw new Error('INVALID_WORKSPACE_SETTINGS');
      tools.protectedUrls = message.protected ? [...new Set([...tools.protectedUrls, url])] : tools.protectedUrls.filter(item => item !== url);
    } else if (message.type === 'save-link-rule' || message.type === 'remove-link-rule') {
      const hostname = websiteHostname(message.type === 'remove-link-rule' ? message.hostname : message.rule?.hostname);
      const previous = message.previousHostname == null ? hostname : websiteHostname(message.previousHostname);
      const current = tools.linkRules.find(rule => rule.hostname === previous);
      // A stale editor must not overwrite a rule saved in another extension window.
      if (Object.hasOwn(message, 'expectedRule') && JSON.stringify(current || null) !== JSON.stringify(message.expectedRule === null ? null : validateLinkRule(message.expectedRule))) throw new Error('LINK_RULE_CHANGED');
      if (hostname !== previous && tools.linkRules.some(rule => rule.hostname === hostname)) throw new Error('LINK_RULE_CHANGED');
      if (message.type === 'save-link-rule' && !Array.isArray(message.rule.parameters)) throw new Error('INVALID_WORKSPACE_SETTINGS');
      const next = message.type === 'save-link-rule' && message.rule.parameters.length ? validateLinkRule(message.rule) : null;
      tools.linkRules = tools.linkRules.filter(rule => rule.hostname !== previous);
      if (next) tools.linkRules.push(next);
    } else {
      const hostname = websiteHostname(message.hostname), label = validateWebsiteLabel(message.label);
      if (['__proto__', 'constructor', 'prototype'].includes(hostname)) throw new Error('INVALID_WORKSPACE_SETTINGS');
      if (label.values.length) tools.labels[hostname] = label; else delete tools.labels[hostname];
    }
    await chrome.storage.local.set({ [WORKSPACE_TOOLS_KEY]: tools });
    if (message.type === 'save-link-rule' || message.type === 'remove-link-rule') {
      if (message.type === 'remove-link-rule' || !message.rule.parameters.length || message.rule.enabled === false || message.previousHostname && message.previousHostname !== message.rule.hostname) {
        await automaticLinks.setAutomatic(message.previousHostname || message.hostname || message.rule.hostname, false);
      }
      await automaticLinks.reconcile();
    }
    return { tools };
  });
  if (message.type === 'get-local-backup') {
    const tools = await readWorkspaceTools(chrome.storage.local);
    const { config } = await autoCleanup.handle({ type: 'auto-get' }, owner);
    return { protection: { sites: await readProtectedSites(), urls: tools.protectedUrls },
      browsing: await readBrowsingPreferences(chrome.storage.local), tasks: validateLocalBackup({ tasks: config.rules.map(normalizeRule) }).tasks };
  }
  if (message.type === 'restore-local-backup') return withPolicyLock(async () => {
    if (deletionRunning() || applyingUpdate) throw new Error('RULES_BUSY');
    const config = validateSyncConfig(message.config), local = validateLocalBackup(message.localSettings);
    if (!Array.isArray(message.sections) || !message.sections.length || message.sections.some(section => !['preferences', 'protection', 'browsing', 'tasks', 'connection'].includes(section))) throw new Error('INVALID_BACKUP');
    const sections = new Set(message.sections);
    for (const section of ['protection', 'browsing', 'tasks']) if (sections.has(section) && !Object.hasOwn(local, section)) throw new Error('INVALID_BACKUP');
    const connection = sections.has('connection') ? validateConnection(message.connection) : undefined;
    return queueCleanup(async () => {
      const patch = {};
      if (sections.has('preferences')) patch.launchMode = config.preferences.launchMode;
      if (sections.has('connection')) patch[CONNECTION_KEY] = connection;
      if (sections.has('protection')) {
        const tools = await readWorkspaceTools(chrome.storage.local);
        patch.protectedSites = local.protection.sites;
        patch[WORKSPACE_TOOLS_KEY] = { ...tools, protectedUrls: local.protection.urls };
      }
      if (sections.has('browsing')) patch.browsingPreferences = local.browsing;
      if (sections.has('tasks')) {
        const { config: current } = await autoCleanup.handle({ type: 'auto-get' }, owner);
        patch.autoCleanup = pausedTaskConfig(local.tasks, current.revision);
      }
      // One storage mutation applies the chosen categories; old live task state is never replayed.
      await chrome.storage.local.set(patch);
      const schedulePending = sections.has('tasks') && !await autoCleanup.configurationChanged().then(() => true, () => false);
      return { schedulePending };
    });
  });
  if (message.type === 'claim-nameplate-reveal') return { nameplate: await nameplates.claimReveal() };
  if (message.type === 'get-nameplate') return { nameplate: await nameplates.issue() };
  if (message.type.startsWith('auto-')) {
    // A modal reaches this branch only after the one-use launch/session check succeeds.
    const page = new URL(sender.url).pathname;
    if (!modal && !['/auto-cleanup.html','/manager.html','/popup.html'].includes(page)) throw new Error('AUTO_UNAVAILABLE');
    await autoCleanup.initialize();
    return autoCleanup.handle(message, owner);
  }
  if (message.type === 'open-auto-cleanup') {
    let fragment = '';
    if (message.domain !== undefined) {
      const sites = parseProtectedSites(message.domain);
      if (sites.length !== 1 || typeof message.includeSubdomains !== 'boolean') throw new Error('AUTO_INVALID_RULE');
      fragment = '#' + new URLSearchParams({ domain: sites[0], subdomains: message.includeSubdomains ? '1' : '0' });
    }
    await chrome.tabs.create({ url: chrome.runtime.getURL(`auto-cleanup.html${fragment}`) });
    return {};
  }
  if (message.type === 'get-activity') return activityLog.read();
  if (message.type === 'get-update-state') return withPolicyLock(readUpdateState);
  if (message.type === 'check-for-update') {
    // Never hold the deletion policy lock while waiting for the website or Chrome's downloader.
    if (!(await withPolicyLock(readUpdateState)).update) {
      const version = await checkForUpdate({ manual: message.manual === true });
      if (version) await recordAvailableUpdate(version);
    }
    return withPolicyLock(readUpdateState);
  }
  if (message.type === 'apply-update') return withPolicyLock(async () => {
    if (applyingUpdate) throw new Error('UPDATE_RELOADING');
    const { update } = await readUpdateState();
    if (!update) throw new Error('UPDATE_UNAVAILABLE');
    if (deletionRunning()) throw new Error('UPDATE_BUSY');
    // Serialize reload with deletion acceptance, including requests from other open views.
    applyingUpdate = true;
    try { chrome.runtime.reload(); } catch (error) { applyingUpdate = false; throw error; }
    return {};
  });
  if (message.type === 'claim-rating-invite') {
    if (!modal && !['/manager.html', '/popup.html'].includes(new URL(sender.url).pathname)) throw new Error('Invalid page');
    return withPolicyLock(async () => {
      const { ratingInviteShown } = await chrome.storage.local.get('ratingInviteShown');
      if (ratingInviteShown) return { show: false };
      // Claim once across all workspace views, without retaining the deletion details.
      await chrome.storage.local.set({ ratingInviteShown: true });
      return { show: true };
    });
  }
  if (message.type === 'claim-activity-scroll-hint') return withPolicyLock(async () => {
    const { activityScrollHint: hint } = await chrome.storage.local.get('activityScrollHint');
    // Older installations have no reliable install date; updates must not restart onboarding.
    if (!hint || !Number.isFinite(hint.installedAt) || hint.installedAt <= 0 ||
        (hint.lastShownOn !== null && (typeof hint.lastShownOn !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(hint.lastShownOn)))) return { show: false };
    const now = new Date(), installed = new Date(hint.installedAt);
    const day = date => Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
    const elapsed = (day(now) - day(installed)) / 86400000;
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    if (!Number.isFinite(elapsed) || elapsed < 0 || elapsed >= 3 || (hint.lastShownOn !== null && hint.lastShownOn >= today)) return { show: false };
    // The worker serializes claims across popup, full-page and modal surfaces.
    await chrome.storage.local.set({ activityScrollHint: { installedAt: hint.installedAt, lastShownOn: today } });
    return { show: true };
  });
  if (message.type === 'get-launch-preference') return { launchMode: await launcher.getMode() };
  if (message.type === 'set-launch-preference') return { launchMode: await launcher.setMode(message.launchMode) };
  if (message.type === 'open-workspace') {
    if (typeof message.query !== 'string' || !modes.has(message.mode)) throw new Error('Invalid handoff');
    // Older open pages may still send the original handoff shape until reloaded.
    await openWorkspace(message.query, message.mode, message.filters === undefined ? defaultTimeFilter() : message.filters);
    return {};
  }
  if (message.type === 'claim-workspace') {
    if (new URL(sender.url).pathname !== '/manager.html') throw new Error('Invalid page');
    const handoff = handoffs.get(message.handoffId);
    handoffs.delete(message.handoffId);
    if (!handoff || handoff.expires < Date.now()) throw new Error('Expired handoff');
    return { query: handoff.query, mode: handoff.mode, filters: handoff.filters };
  }
  if (message.type === 'current-site') {
    if (new URL(sender.url).pathname !== '/popup.html') throw new Error('CURRENT_SITE_UNAVAILABLE');
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return { hostname: websiteHost(tab?.url) };
  }
  if (message.type === 'get-protection') return withPolicyLock(async () => ({ sites: await readProtectedSites(), urls: await readProtectedUrls(chrome.storage.local) }));
  if (message.type === 'save-protection') {
    const sites = parseProtectedSites(message.input);
    return withPolicyLock(async () => {
      // A newly protected site must never race a confirmed deletion already in flight.
      if (deletionRunning()) throw new Error('RULES_BUSY');
      await chrome.storage.local.set({ protectedSites: sites });
      return { sites };
    });
  }
  if (message.type === 'start-delete') {
    if (!Array.isArray(message.urls) || !message.urls.length || message.urls.length > 100000 ||
        !message.urls.every(url => {
          if (typeof url !== 'string') return false;
          try { new URL(url); return true; } catch { return false; }
        })) throw new Error('Invalid URLs');
    return withPolicyLock(async () => {
      if (applyingUpdate) throw new Error('UPDATE_RELOADING');
      const sites = await readProtectedSites();
      const protectedUrls = new Set(await readProtectedUrls(chrome.storage.local));
      if (message.urls.some(url => isProtectedUrl(url, sites) || protectedUrls.has(url))) throw new Error('PROTECTED_URL');
      // Capture privacy before deletion; a failed read must not risk logging a private cleanup.
      const { privateCleanup = false } = await chrome.storage.local.get('privateCleanup');
      if (typeof privateCleanup !== 'boolean') throw new Error('INVALID_CLEANUP_PREFERENCE');
      // The worker owns the operation, independent of the popup/message channel.
      const job = { id: crypto.randomUUID(), owner, total: new Set(message.urls).size, completed: 0, phase: 'deleting', remaining: [], privateCleanup };
      await chrome.storage.local.set({ [MANUAL_CLEANUP_KEY]: { id: job.id, pending: true } });
      jobs.set(job.id, job);
      // Notify every view without making history deletion depend on update UI storage.
      await publishUpdateState().catch(() => {});
      const selected = new Set(message.urls);
      const details = new Map();
      if (Array.isArray(message.details)) for (const item of message.details) {
        if (!item || !selected.has(item.url)) continue;
        details.set(item.url, {
          ...(typeof item.title === 'string' ? { title: item.title } : {}),
          ...(Number.isFinite(item.lastVisitTime) && item.lastVisitTime > 0 ? { lastVisitTime: item.lastVisitTime } : {}),
        });
      }
      void queueCleanup(() => runDeletion(job, [...selected], details));
      return snapshot(job);
    });
  }
  if (message.type === 'delete-status') {
    const job = jobs.get(message.id);
    if (!job || job.owner !== owner) throw new Error('Missing job');
    return snapshot(job);
  }
  if (message.type === 'release-delete') {
    const job = jobs.get(message.id);
    if (job?.owner === owner && !['deleting', 'verifying'].includes(job.phase)) jobs.delete(message.id);
    return {};
  }
  throw new Error('Unknown message');
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!message || typeof message.type !== 'string') return false;
  // Web-accessible modal frames must claim a toolbar-created session before accessing the UI.
  if (message.type === 'claim-modal') {
    launcher.claimModal(message.token, sender).then(ok => respond({ ok }), () => respond({ ok: false }));
    return true;
  }
  let owner;
  let modal = false;
  try {
    modal = sender.id === chrome.runtime.id && sender.frameId > 0 &&
      sender.url.split('#')[0] === chrome.runtime.getURL('modal.html');
    if (!modal && !trustedPage(sender)) return false;
    owner = ownerKey(message, sender);
  }
  catch { return false; }
  const authorized = modal ? launcher.isTrustedModal(sender) : Promise.resolve(true);
  authorized.then(trusted => {
    if (!trusted) throw new Error('Invalid modal session');
    return handleMessage(message, sender, owner, modal);
  }).then(data => respond({ ok: true, data }), error => {
    if (isAgentMessage(message)) { respond({ ok: false, code: agentError(error) }); return; }
    const code = ['CURRENT_SITE_UNAVAILABLE', 'INVALID_TIME_RANGE', 'INVALID_PROTECTED_SITES', 'RULES_BUSY', 'PROTECTED_URL', 'UPDATE_BUSY', 'UPDATE_UNAVAILABLE', 'UPDATE_RELOADING',
      'INVALID_WORKSPACE_SETTINGS', 'INVALID_BACKUP', 'LINK_UNAVAILABLE', 'LINK_RULE_CHANGED', 'LINK_AUTO_UNSUPPORTED', 'INVALID_LINK_AUTOMATIC', 'AUTO_INVALID_RULE', 'AUTO_CONFLICT', 'AUTO_STALE', 'AUTO_PREVIEW_REQUIRED', 'AUTO_PREVIEW_EXPIRED', 'AUTO_SCAN_INCOMPLETE', 'AUTO_FULLY_PROTECTED', 'AUTO_BUSY', 'AUTO_UNAVAILABLE', 'AUTO_ACTIVITY_FAILED'].includes(error.message) ? error.message : undefined;
    respond({ ok: false, ...(code ? { code } : {}) });
  });
  return true;
});

if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener(alarm => {
    if (alarm.name === AUTO_CLEANUP_ALARM) void autoCleanup.initialize().then(() => autoCleanup.checkDue()).catch(() => {});
  });
  chrome.runtime.onStartup.addListener(() => { void autoCleanup.initialize().then(() => autoCleanup.checkDue()).catch(() => {}); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && Object.hasOwn(changes, 'privateCleanup')) void autoCleanup.privacyChanged(changes.privateCleanup.newValue).catch(() => {});
  });
  // Recreate alarms on every worker start; Chrome versions below 150 may discard them on restart.
  void autoCleanup.initialize().catch(() => {});
}
